#!/usr/bin/env bash

CURRENT_DIR=$(cd $(dirname $0); pwd)

ps -ef | grep ${CURRENT_DIR}/cse | grep -v grep | awk -F ' ' '{print $2}'|while read line
do
  echo "Shutting down Local-CSE(PID: $line)..."
  eval "kill -9 $line"
done

echo "Done!"